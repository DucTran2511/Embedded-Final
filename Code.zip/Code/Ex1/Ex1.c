/*
 * Ex1.c
 *
 * Created: 12/21/2024 10:31:33 PM
 * Author: ADMIN
 */

#include <mega128.h>
#include <delay.h>
#include <alcd.h> // Thu vi?n LCD trong CodeVision

#define DHT11_PIN PINB.7
#define DHT11_PIN_DIR DDRB.7
#define DHT11_PIN_OUT PORTB.7

unsigned char dht11_data[5];

void DHT11_Request() {
    DHT11_PIN_DIR = 1; // Cau hinh ch�n PB7 l�m output
    DHT11_PIN_OUT = 0; // K�o ch�n PB7 xuong muc thap
    delay_ms(20);      // Giu muc thap it nhat 18us (an to�n hon voi 20ms)
    DHT11_PIN_OUT = 1; // Keo chan PB7 len muc cao
    delay_us(30);      // Giu muc cao 20-40us
    DHT11_PIN_DIR = 0; // Cau hinh ch�n PB7 l�m input
}

unsigned char DHT11_WaitForResponse() {
    delay_us(40);
    if (DHT11_PIN == 0) { // Wait tin hieu tu DHT11 keo xuong
        delay_us(80);
        if (DHT11_PIN == 1) { // Wait tin hieu DHT11 keo len
            delay_us(40);
            return 1; // Phan hoi thanh cong
        }
    }
    return 0; // Phan hoi that bai
}

unsigned char DHT11_ReadByte() {
    unsigned char i, data = 0;
    for (i = 0; i < 8; i++) {
        while (!DHT11_PIN); // Wait bit bat dau (muc cao)
        delay_us(40); // Wait 40us de xac dinh tin hieu bit
        if (DHT11_PIN == 1) {
            data = (data << 1) | 1; // Ghi bit 1
        } else {
            data = (data << 1);     // Ghi bit 0
        }
        while (DHT11_PIN); // Wait ket thuc t�n hieu bit (muc thap)
    }
    return data;
}

unsigned char DHT11_ReadData() {
    unsigned char i;
    DHT11_Request();
    if (DHT11_WaitForResponse()) {
        for (i = 0; i < 5; i++) {
            dht11_data[i] = DHT11_ReadByte();
        }
        if ((dht11_data[0] + dht11_data[1] + dht11_data[2] + dht11_data[3]) == dht11_data[4]) {
            return 1; // Du lieu hop le
        }
    }
    return 0; // Du lieu khong hop le
}

void nhietdovadoam() {
    unsigned char temperature, humidity, temp_decimal, hum_decimal;

    if (DHT11_ReadData()) {
        humidity = dht11_data[0];
        hum_decimal = dht11_data[1];
        temperature = dht11_data[2];
        temp_decimal = dht11_data[3];

        lcd_clear();
        lcd_gotoxy(0, 0);
        lcd_puts("Nhiet do: ");
        lcd_putchar((temperature / 10) + '0');
        lcd_putchar((temperature % 10) + '0');
        lcd_putchar('.');
        lcd_putchar((temp_decimal / 10) + '0');
        lcd_putchar((temp_decimal % 10) + '0');
        lcd_putchar(0b11011111); // K� t? d? C
        lcd_puts("C");

        lcd_gotoxy(0, 1);
        lcd_puts("Do am: ");
        lcd_putchar((humidity / 10) + '0');
        lcd_putchar((humidity % 10) + '0');
        lcd_putchar('.');
        lcd_putchar((hum_decimal / 10) + '0');
        lcd_putchar((hum_decimal % 10) + '0');
        lcd_puts("%");
    } else {
        lcd_clear();
        lcd_putsf("Loi doc DHT11!");
    }
}

void main() {
    // Kh?i d?ng LCD
    lcd_init(16);
    lcd_clear();
    lcd_putsf("DHT11 Test\n");
    delay_ms(2000);

    while (1) {
        nhietdovadoam();
        delay_ms(2000); // Doc v� hien thi du lieu moi trong 2s
    }
}
