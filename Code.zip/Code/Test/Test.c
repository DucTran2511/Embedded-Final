/*
 * Test.c
 *
 * Created: 12/21/2024 12:55:02 PM
 * Author: ADMIN
 */

#include <io.h>

void main(void)
{
while (1)
    {
    // Please write your application code here

    }
}
