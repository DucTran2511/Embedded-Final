/*
 * Ex1 LCD.c
 *
 * Created: 12/21/2024 10:37:54 PM
 * Author: ADMIN
 */

#include <mega128.h>
#include <delay.h>
#include <glcd.h>
#include <font5x7.h>
#include <stdlib.h>
#include <stdio.h>

#define DHT11_PIN PINB.7
#define DHT11_PIN_DIR DDRB.7
#define DHT11_PIN_OUT PORTB.7
#define BT1 PINB.2 // N�t nh?n k?t th�c qu� tr�nh nh?p ngu?ng
#define BT2 PINB.3

unsigned char dht11_data[5];
int temp_threshold = 25; // Ngu?ng nhi?t m?c d?nh

int keypad[3][3] = {
    {'0', '1', '2'},
    {'3', '4', '5'},
    {'6', '7', '8'}
};

void init_glcd() {
    GLCDINIT_t glcd_init_data;
    glcd_init_data.font = font5x7;
    glcd_init_data.temp_coef = 140;
    glcd_init_data.bias = 4;
    glcd_init_data.vlcd = 66;
    glcd_init(&glcd_init_data);
}

void DHT11_Request() {
    DHT11_PIN_DIR = 1; // C?u h�nh ch�n PB7 l�m output
    DHT11_PIN_OUT = 0; // K�o ch�n PB7 xu?ng m?c th?p
    delay_ms(20);      // Gi? m?c th?p �t nh?t 18ms (an to�n hon v?i 20ms)
    DHT11_PIN_OUT = 1; // K�o ch�n PB7 l�n m?c cao
    delay_us(30);      // Gi? m?c cao 20-40us
    DHT11_PIN_DIR = 0; // C?u h�nh ch�n PB7 l�m input
}

unsigned char DHT11_WaitForResponse() {
    delay_us(40);
    if (DHT11_PIN == 0) { // Ch? t�n hi?u t? DHT11 k�o xu?ng
        if (DHT11_PIN == 1) { // Ch? t�n hi?u DHT11 k�o l�n
            delay_us(40);
            return 1; // Ph?n h?i th�nh c�ng
        }
    }
    return 0; // Ph?n h?i th?t b?i
}

unsigned char DHT11_ReadByte() {
    unsigned char i, data = 0;
    for (i = 0; i < 8; i++) {
        while (!DHT11_PIN); // Ch? bit b?t d?u (m?c cao)
        delay_us(40); // Ch? 40us d? x�c d?nh t�n hi?u bit
        if (DHT11_PIN == 1) {
            data = (data << 1) | 1; // Ghi bit 1
        } else {
            data = (data << 1);     // Ghi bit 0
        }
        while (DHT11_PIN); // Ch? k?t th�c t�n hi?u bit (m?c th?p)
    }
    return data;
}

unsigned char DHT11_ReadData() {
    unsigned char i;
    DHT11_Request();
    if (DHT11_WaitForResponse()) {
        for (i = 0; i < 5; i++) {
            dht11_data[i] = DHT11_ReadByte();
        }
        if ((dht11_data[0] + dht11_data[1] + dht11_data[2] + dht11_data[3]) == dht11_data[4]) {
            return 1; // D? li?u h?p l?
        }
    }
    return 0; // D? li?u kh�ng h?p l?
}

unsigned char get_keypad() {
    unsigned char row, col;
    for (col = 0; col < 3; col++) {
        // K�o t?ng c?t xu?ng m?c th?p
        if (col == 0) PORTF = 0b11111101;
        if (col == 1) PORTF = 0b11110111;
        if (col == 2) PORTF = 0b11011111;

        for (row = 0; row < 3; row++) {
            if (row == 0 && PINF.2 == 0) { // Ki?m tra tra h�ng 1
                while (PINF.2 == 0); // Ch? ph�m nh?
                return keypad[row][col];
            }
            if (row == 1 && PINF.4 == 0) { // Ki?m tra h�ng 2
                while (PINF.4 == 0); // Ch? ph�m nh?
                return keypad[row][col];
            }
            if (row == 2 && PINF.0 == 0) { // Ki?m tra h�ng 3
                while (PINF.0 == 0); // Ch? ph�m nh?
                return keypad[row][col];
            }
        }
    }
    if (BT2 == 0) { // BT2 d?i di?n cho s? 9
        while (BT2 == 0); // Ch? ph�m nh?
        return '9';
    }
    return 0; // Kh�ng c� ph�m n�o du?c nh?n
}

void nhapnguong() {
    char buffer[16];
    unsigned char key;
    unsigned char cursor_x = 0; // V? tr� ban d?u d? hi?n th? gi� tr? nh?p
    temp_threshold = 0; // Reset gi� tr? ngu?ng
    glcd_clear();
    glcd_outtextxy(0, 0, "Nhap nguong:");
    while (1) {
        key = get_keypad(); //  �?c ph�m t? b�n ph�m
        if (key >= '0' && key <= '8') { // Nh?n c�c ph�m t? 0 d?n 8
            temp_threshold = temp_threshold * 10 + (key - '0');
            buffer[0] = key;
            buffer[1] = '\0';
            glcd_outtextxy(cursor_x, 8, buffer); // Hi?n th? s? v?a nh?p
            cursor_x += 8; // D?ch con tr? sang ph?i d? kho?ng c�ch d? tr�nh d�
        }
        else if (key == '9') { /// N?u BT2 d?i di?n cho s? 9
            temp_threshold = temp_threshold * 10 + 9;
            buffer[0] = '9';
            buffer[1] = '\0';
            glcd_outtextxy(cursor_x, 8, buffer);
            cursor_x += 8;
        }
        if (BT1 == 0) { // N�t nh?n k?t th�c nh?p ngu?ng
            while (BT1 == 0); // Ch? nh? n�t
            break;
        }
    }
    glcd_clear();
    glcd_outtextxy(0, 0, "Nguong:");
    sprintf(buffer, "%dC", temp_threshold);
    glcd_outtextxy(50, 0, buffer);
    delay_ms(3000);
}

void nhietdovadoam() {
    char buffer[16];
    unsigned char temperature, humidity, temp_decimal, hum_decimal;

    if (DHT11_ReadData()) {
        humidity = dht11_data[0];
        hum_decimal = dht11_data[1];
        temperature = dht11_data[2];
        temp_decimal = dht11_data[3];

        glcd_clear();
        glcd_outtextxy(0, 0, "Nhiet do:");
        sprintf(buffer, "%d.%dC", temperature, temp_decimal);
        glcd_outtextxy(0, 8, buffer);

        glcd_outtextxy(0, 16, "Do am:");
        sprintf(buffer, "%d.%d%%", humidity, hum_decimal);
        glcd_outtextxy(0, 24, buffer);

        if (temperature >= temp_threshold) {
            glcd_outtextxy(0, 32, "Warning");
        } else {
            glcd_outtextxy(0, 32, "...");
        }
    } else {
        glcd_clear();
        glcd_outtextxy(0, 0, "Loi doc DHT11!");
    }
}

void main() {
    init_glcd(); // Kh?i t?o GLCD

    DDRF = 0b11101010;  // PortF.7.6.5.3.1 l� output, 0.2.4 l� input
    PORTF = 0b00010101; // K�o c�c h�ng l�n m?c cao
    DDRB.2 = 0; // Thi?t l?p PB2 l�m input cho n�t nh?n BT1
    PORTB.2 = 1; // K�o l�n m?c cao (pull-up resistor) cho BT1
    DDRB.3 = 0;
    PORTB.3 = 1;

    glcd_clear();
    glcd_outtextxy(0, 0, "DHT11 Test");
    delay_ms(2000);

    nhapnguong(); // Cho ph�p ngu?i d�ng nh?p ngu?ng

    while (1) {
        nhietdovadoam();
        delay_ms(2000); // �?c v� hi?n th? d? li?u m?i 2 gi�y
    }
}
